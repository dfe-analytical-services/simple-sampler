This shiny app is a reuseable template showcasing the functions from the `shinyLP` package.

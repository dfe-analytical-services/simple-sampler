library(testthat)
library(shinyLP)

test_check("shinyLP")
